import json

try:
    with open('users_debug.json', 'r', encoding='utf-16') as f:
        data = json.load(f)
        users = data.get('data', [])
        for user in users:
            if user.get('email') == 'trainer@lms.com':
                print(f"User: {user.get('email')}")
                # Print all keys to see if 'active' or 'isActive' is present
                print(f"Keys: {list(user.keys())}")
                print(f"Active field: {user.get('active')}")
                print(f"IsActive field: {user.get('isActive')}")
                print(f"Roles: {user.get('roles')}")
                print("-" * 20)
except Exception as e:
    print(f"Error: {e}")
