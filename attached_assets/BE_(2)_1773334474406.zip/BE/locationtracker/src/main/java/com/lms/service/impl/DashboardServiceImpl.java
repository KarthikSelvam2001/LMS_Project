package com.lms.service.impl;

import com.lms.repository.IAttendanceRepository;
import com.lms.repository.ICertificateRepository;
import com.lms.repository.ICourseRepository;
import com.lms.service.IDashboardService;
import com.lms.repository.IEnrollmentRepository;
import com.lms.entity.User;
import com.lms.repository.UserRepository;
import com.lms.response.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@Service
public class DashboardServiceImpl implements IDashboardService {

    @Autowired
    private IEnrollmentRepository enrollmentRepository;

    @Autowired
    private ICourseRepository courseRepository;

    @Autowired
    private ICertificateRepository certificateRepository;

    @Autowired
    private IAttendanceRepository attendanceRepository;

    @Autowired
    private UserRepository userRepository;

    @Override
    public ApiResponse<Object> getLearnerDashboard(String userId) {
        Map<String, Object> dashboard = new HashMap<>();
        dashboard.put("enrolledCoursesCount", enrollmentRepository.countByUserIdAndIsDeletedFalse(userId));
        dashboard.put("completedCoursesCount",
                enrollmentRepository.countByUserIdAndCompletedTrueAndIsDeletedFalse(userId));
        dashboard.put("certificatesCount", certificateRepository.countByUserId(userId));
        dashboard.put("enrollments", enrollmentRepository.findByUserIdAndIsDeletedFalse(userId));
        dashboard.put("certificates", certificateRepository.findByUserId(userId));
        return ApiResponse.success(dashboard);
    }

    @Override
    public ApiResponse<Object> getTrainerDashboard(String trainerId) {
        Map<String, Object> dashboard = new HashMap<>();
        dashboard.put("createdCoursesCount", courseRepository.countByTrainerIdAndIsDeletedFalse(trainerId));
        // Note: Upcoming sessions logic requires linking to new attendance methods.
        // dashboard.put("upcomingSessions",
        // sessionRepository.findByTrainerIdAndIsDeletedFalse(trainerId));
        // dashboard.put("upcomingSessionsCount",
        // sessionRepository.findByTrainerIdAndIsDeletedFalse(trainerId).size());
        return ApiResponse.success(dashboard);
    }

    @Override
    public ApiResponse<Object> getAdminDashboard() {
        Map<String, Object> dashboard = new HashMap<>();
        dashboard.put("totalUsersCount", userRepository.count());
        dashboard.put("totalCoursesCount", courseRepository.countByIsDeletedFalse());
        dashboard.put("totalEnrollmentsCount", enrollmentRepository.countByIsDeletedFalse());
        return ApiResponse.success(dashboard);
    }
}
