package com.lms.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import java.time.LocalDateTime;

@EqualsAndHashCode(callSuper = true)
@Data
@Document("enrollments")
public class Enrollment extends BaseEntity {

    @Id
    private String id;

    private String userId;
    private String courseId;
    private Double progress = 0.0;
    private boolean completed = false;
    private LocalDateTime enrolledAt = LocalDateTime.now();

    public Double getProgressPercentage() {
        return progress;
    }

    public void setProgressPercentage(double progressPercentage) {
        this.progress = progressPercentage;
    }

    public boolean isCompleted() {
        return completed || (progress != null && progress >= 100.0);
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public Double getProgress() {
        return progress;
    }

    public void setProgress(Double progress) {
        this.progress = progress;
    }

    public void setCompleted(boolean completed) {
        this.completed = completed;
    }

    public LocalDateTime getEnrolledAt() {
        return enrolledAt;
    }

    public void setEnrolledAt(LocalDateTime enrolledAt) {
        this.enrolledAt = enrolledAt;
    }
}
