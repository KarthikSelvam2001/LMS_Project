package com.lms.lesson.controller;

import com.lms.entity.Lesson;
import com.lms.lesson.dto.LessonRequest;
import com.lms.response.ApiResponse;
import jakarta.validation.Valid;

import java.util.List;

public interface ILessonController {
    ApiResponse<Lesson> createLesson(String moduleId, @Valid LessonRequest request);

    ApiResponse<Lesson> updateLesson(String lessonId, @Valid LessonRequest request);

    ApiResponse<String> deleteLesson(String lessonId);

    ApiResponse<List<Lesson>> getModuleLessons(String moduleId);
}
