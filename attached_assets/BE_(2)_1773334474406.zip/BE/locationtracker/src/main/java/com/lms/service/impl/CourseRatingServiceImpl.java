package com.lms.service.impl;

import com.lms.responsedto.PageResponse;
import com.lms.repository.ICourseRepository;
import com.lms.entity.Course;
import com.lms.entity.CourseRating;
import com.lms.requestdto.CourseRatingRequest;
import com.lms.repository.ICourseRatingRepository;
import com.lms.service.ICourseRatingService;
import com.lms.response.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class CourseRatingServiceImpl implements ICourseRatingService {

    @Autowired
    private ICourseRatingRepository ratingRepository;
    @Autowired
    private ICourseRepository courseRepository;

    @Override
    public ApiResponse<CourseRating> addOrUpdateRating(CourseRatingRequest request, String userId) {
        Course course = courseRepository.findByIdAndIsDeletedFalse(request.getCourseId()).orElse(null);
        if (course == null)
            return ApiResponse.error(404, "Course not found");

        Optional<CourseRating> existingOpt = ratingRepository.findByUserIdAndCourseIdAndIsDeletedFalse(userId,
                request.getCourseId());
        CourseRating rating = existingOpt.orElse(new CourseRating());

        rating.setUserId(userId);
        rating.setCourseId(request.getCourseId());
        rating.setRating(request.getRating());
        rating.setReview(request.getReview());
        rating.setUpdatedBy(userId);
        rating.setUpdatedAt(LocalDateTime.now());

        if (rating.getId() == null) {
            rating.setCreatedBy(userId);
            rating.setCreatedAt(LocalDateTime.now());
        }

        return ApiResponse.success(ratingRepository.save(rating));
    }

    @Override
    public ApiResponse<Object> getCourseRatings(String courseId, int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        Page<CourseRating> ratingsPage = ratingRepository.findByCourseIdAndIsDeletedFalse(courseId, pageable);
        return ApiResponse.success(buildPageResponse(ratingsPage));
    }

    @Override
    public ApiResponse<Double> getCourseAverageRating(String courseId) {
        Pageable pageable = Pageable.unpaged(); // get all
        Page<CourseRating> allRatings = ratingRepository.findByCourseIdAndIsDeletedFalse(courseId, pageable);

        if (allRatings.isEmpty()) {
            return ApiResponse.success(0.0);
        }

        double sum = 0;
        for (CourseRating r : allRatings) {
            sum += r.getRating();
        }

        return ApiResponse.success(sum / allRatings.getTotalElements());
    }

    private <T> PageResponse<T> buildPageResponse(Page<T> page) {
        PageResponse<T> response = new PageResponse<>();
        response.setContent(page.getContent());
        response.setPageNumber(page.getNumber());
        response.setPageSize(page.getSize());
        response.setTotalElements(page.getTotalElements());
        response.setTotalPages(page.getTotalPages());
        response.setLast(page.isLast());
        return response;
    }
}
