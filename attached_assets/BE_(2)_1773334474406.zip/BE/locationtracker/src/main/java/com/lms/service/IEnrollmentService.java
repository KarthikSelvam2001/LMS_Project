package com.lms.service;

import com.lms.requestdto.EnrollmentRequest;
import com.lms.entity.Enrollment;
import com.lms.response.ApiResponse;

public interface IEnrollmentService {
    ApiResponse<Enrollment> enrollUser(EnrollmentRequest request, String userId);

    ApiResponse<Enrollment> getEnrollment(String courseId, String userId);

    ApiResponse<Object> getUserEnrollments(String userId, int page, int size);

    ApiResponse<Object> getCourseEnrollments(String courseId, String trainerId, int page, int size);
}
