package com.lms.repository;

import com.lms.entity.Leaderboard;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ILeaderboardRepository extends MongoRepository<Leaderboard, String> {
    Optional<Leaderboard> findByUserIdAndIsDeletedFalse(String userId);

    Page<Leaderboard> findByIsDeletedFalseOrderByPointsDesc(Pageable pageable);
}
