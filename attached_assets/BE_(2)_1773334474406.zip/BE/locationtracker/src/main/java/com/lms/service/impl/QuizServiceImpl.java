package com.lms.service.impl;

import com.lms.requestdto.QuizAttemptRequest;
import com.lms.requestdto.QuizRequest;
import com.lms.entity.Lesson;
import com.lms.entity.Module;
import com.lms.entity.Course;
import com.lms.entity.Quiz;
import com.lms.entity.Quiz.Question;
import com.lms.entity.QuizAttempt;
import com.lms.repository.ICourseRepository;
import com.lms.repository.IModuleRepository;
import com.lms.repository.ILessonRepository;
import com.lms.repository.IQuizRepository;
import com.lms.repository.IQuizAttemptRepository;
import com.lms.service.IQuizService;
import com.lms.response.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class QuizServiceImpl implements IQuizService {

    @Autowired
    private IQuizRepository quizRepository;
    @Autowired
    private IQuizAttemptRepository quizAttemptRepository;
    @Autowired
    private ILessonRepository lessonRepository;
    @Autowired
    private IModuleRepository moduleRepository;
    @Autowired
    private ICourseRepository courseRepository;

    private boolean isTrainerAuthorized(String lessonId, String trainerId) {
        Lesson lesson = lessonRepository.findById(lessonId).orElse(null);
        if (lesson == null || lesson.getDeleted())
            return false;

        Module module = moduleRepository.findById(lesson.getModuleId()).orElse(null);
        if (module == null || module.getDeleted())
            return false;

        Course course = courseRepository.findById(module.getCourseId()).orElse(null);
        if (course == null || course.getDeleted())
            return false;

        return course.getTrainerId().equals(trainerId);
    }

    @Override
    public ApiResponse<Quiz> createOrUpdateQuiz(String lessonId, QuizRequest request, String trainerId) {
        if (!isTrainerAuthorized(lessonId, trainerId)) {
            return ApiResponse.error(403, "Not authorized to manage quiz for this lesson");
        }

        Optional<Quiz> existingOpt = quizRepository.findByLessonIdAndIsDeletedFalse(lessonId);
        Quiz quiz = existingOpt.orElse(new Quiz());

        quiz.setLessonId(lessonId);
        quiz.setQuestions(request.getQuestions());
        quiz.setUpdatedBy(trainerId);
        quiz.setUpdatedAt(LocalDateTime.now());

        if (quiz.getId() == null) {
            quiz.setCreatedBy(trainerId);
            quiz.setCreatedAt(LocalDateTime.now());
        }

        return ApiResponse.success(quizRepository.save(quiz));
    }

    @Override
    public ApiResponse<Quiz> getQuizByLesson(String lessonId) {
        Quiz quiz = quizRepository.findByLessonIdAndIsDeletedFalse(lessonId).orElse(null);
        if (quiz == null)
            return ApiResponse.error(404, "Quiz not found");
        return ApiResponse.success(quiz);
    }

    @Override
    public ApiResponse<String> deleteQuiz(String quizId, String trainerId) {
        Quiz quiz = quizRepository.findById(quizId).orElse(null);
        if (quiz == null || quiz.getDeleted())
            return ApiResponse.error(404, "Quiz not found");

        if (!isTrainerAuthorized(quiz.getLessonId(), trainerId)) {
            return ApiResponse.error(403, "Not authorized");
        }

        quiz.setDeleted(true);
        quiz.setUpdatedBy(trainerId);
        quiz.setUpdatedAt(LocalDateTime.now());
        quizRepository.save(quiz);

        return ApiResponse.success("Quiz deleted successfully");
    }

    @Override
    public ApiResponse<QuizAttempt> submitQuizAttempt(String quizId, QuizAttemptRequest request, String userId) {
        Quiz quiz = quizRepository.findById(quizId).orElse(null);
        if (quiz == null || quiz.getDeleted())
            return ApiResponse.error(404, "Quiz not found");

        int totalQuestions = quiz.getQuestions().size();
        int correctAnswers = 0;

        for (Question q : quiz.getQuestions()) {
            String userAnswer = request.getAnswers().get(q.getQuestion());
            if (userAnswer != null && userAnswer.equals(q.getAnswer())) {
                correctAnswers++;
            }
        }

        double score = ((double) correctAnswers / totalQuestions) * 100;

        Optional<QuizAttempt> lastAttemptOpt = quizAttemptRepository
                .findTopByUserIdAndQuizIdOrderByAttemptNumberDesc(userId, quizId);
        int attemptNumber = lastAttemptOpt.map(a -> a.getAttemptNumber() + 1).orElse(1);

        QuizAttempt attempt = new QuizAttempt();
        attempt.setUserId(userId);
        attempt.setQuizId(quizId);
        attempt.setScore(score);
        attempt.setAttemptNumber(attemptNumber);
        attempt.setCreatedBy(userId);
        attempt.setUpdatedBy(userId);
        attempt.setCreatedAt(LocalDateTime.now());
        attempt.setUpdatedAt(LocalDateTime.now());

        return ApiResponse.success(quizAttemptRepository.save(attempt));
    }

    @Override
    public ApiResponse<Object> getUserQuizAttempts(String quizId, String userId) {
        List<QuizAttempt> attempts = quizAttemptRepository.findByUserIdAndQuizId(userId, quizId);
        return ApiResponse.success(attempts);
    }
}
