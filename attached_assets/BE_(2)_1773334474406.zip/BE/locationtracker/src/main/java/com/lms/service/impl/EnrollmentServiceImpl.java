package com.lms.service.impl;

import com.lms.responsedto.PageResponse;
import com.lms.entity.Course;
import com.lms.entity.CourseStatus;
import com.lms.entity.Enrollment;
import com.lms.repository.ICourseRepository;
import com.lms.requestdto.EnrollmentRequest;
import com.lms.repository.IEnrollmentRepository;
import com.lms.service.IEnrollmentService;
import com.lms.response.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class EnrollmentServiceImpl implements IEnrollmentService {

    @Autowired
    private IEnrollmentRepository enrollmentRepository;
    @Autowired
    private ICourseRepository courseRepository;

    @Override
    public ApiResponse<Enrollment> enrollUser(EnrollmentRequest request, String userId) {
        Course course = courseRepository.findByIdAndIsDeletedFalse(request.getCourseId()).orElse(null);
        if (course == null || course.getStatus() != CourseStatus.PUBLISHED) {
            return ApiResponse.error(404, "Course not found or not published");
        }

        Optional<Enrollment> existingOpt = enrollmentRepository.findByUserIdAndCourseIdAndIsDeletedFalse(userId,
                request.getCourseId());
        if (existingOpt.isPresent()) {
            return ApiResponse.error(400, "User is already enrolled in this course");
        }

        Enrollment enrollment = new Enrollment();
        enrollment.setUserId(userId);
        enrollment.setCourseId(request.getCourseId());
        enrollment.setProgress(0.0);
        enrollment.setEnrolledAt(LocalDateTime.now());
        enrollment.setCreatedBy(userId);
        enrollment.setUpdatedBy(userId);
        enrollment.setCreatedAt(LocalDateTime.now());
        enrollment.setUpdatedAt(LocalDateTime.now());

        return ApiResponse.success(enrollmentRepository.save(enrollment));
    }

    @Override
    public ApiResponse<Enrollment> getEnrollment(String courseId, String userId) {
        Enrollment enrollment = enrollmentRepository.findByUserIdAndCourseIdAndIsDeletedFalse(userId, courseId)
                .orElse(null);
        if (enrollment == null)
            return ApiResponse.error(404, "Enrollment not found");
        return ApiResponse.success(enrollment);
    }

    @Override
    public ApiResponse<Object> getUserEnrollments(String userId, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "enrolledAt"));
        Page<Enrollment> enrollmentPage = enrollmentRepository.findByUserIdAndIsDeletedFalse(userId, pageable);
        return ApiResponse.success(buildPageResponse(enrollmentPage));
    }

    @Override
    public ApiResponse<Object> getCourseEnrollments(String courseId, String trainerId, int page, int size) {
        Course course = courseRepository.findByIdAndIsDeletedFalse(courseId).orElse(null);
        if (course == null || !course.getTrainerId().equals(trainerId)) {
            return ApiResponse.error(403, "Not authorized");
        }

        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "enrolledAt"));
        Page<Enrollment> enrollmentPage = enrollmentRepository.findByCourseIdAndIsDeletedFalse(courseId, pageable);
        return ApiResponse.success(buildPageResponse(enrollmentPage));
    }

    private <T> PageResponse<T> buildPageResponse(Page<T> page) {
        PageResponse<T> response = new PageResponse<>();
        response.setContent(page.getContent());
        response.setPageNumber(page.getNumber());
        response.setPageSize(page.getSize());
        response.setTotalElements(page.getTotalElements());
        response.setTotalPages(page.getTotalPages());
        response.setLast(page.isLast());
        return response;
    }
}
