package com.lms.entity;

public enum QuestionType {
    MCQ,
    DESCRIPTIVE
}
