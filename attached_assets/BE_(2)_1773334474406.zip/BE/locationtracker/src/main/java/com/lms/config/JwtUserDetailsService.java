package com.lms.config;

import com.lms.entity.User;
import com.lms.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class JwtUserDetailsService implements UserDetailsService {

    @Autowired
    @Lazy
    private AuthService authService;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user;
        try {
            user = authService.getUser(username);
        } catch (Exception e) {
            throw new UsernameNotFoundException("User not found: " + username);
        }

        if (user == null) {
            throw new UsernameNotFoundException("User not found: " + username);
        }

        List<GrantedAuthority> listRole = new ArrayList<>();
        if (user.getRoles() != null) {
            user.getRoles().forEach(role -> {
                listRole.add(new org.springframework.security.core.authority.SimpleGrantedAuthority(role));
            });
        }
        return new org.springframework.security.core.userdetails.User(user.getEmail(), user.getPassword(), listRole);
    }
}
