package com.lms.attendance.controller.impl;

import com.lms.attendance.controller.IAttendanceController;
import com.lms.attendance.dto.AttendanceRequest;
import com.lms.attendance.service.IAttendanceService;
import com.lms.config.UserContextHolder;
import com.lms.entity.Attendance;
import com.lms.response.ApiResponse;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1")
public class AttendanceControllerImpl implements IAttendanceController {

    @Autowired
    private IAttendanceService attendanceService;

    @Override
    @PostMapping("/attendance")
    @PreAuthorize("hasRole('LEARNER')")
    public ApiResponse<Attendance> markAttendance(@Valid @RequestBody AttendanceRequest request) {
        String userId = UserContextHolder.getUserDto().getId();
        return attendanceService.markAttendance(request, userId);
    }

    @Override
    @GetMapping("/courses/{courseId}/attendance")
    @PreAuthorize("hasRole('LEARNER')")
    public ApiResponse<Object> getCourseAttendance(
            @PathVariable String courseId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        String userId = UserContextHolder.getUserDto().getId();
        return attendanceService.getCourseAttendance(courseId, userId, page, size);
    }

    @Override
    @GetMapping("/courses/{courseId}/progress")
    @PreAuthorize("hasRole('LEARNER')")
    public ApiResponse<Double> getCourseProgress(@PathVariable String courseId) {
        String userId = UserContextHolder.getUserDto().getId();
        return attendanceService.getCourseProgress(courseId, userId);
    }
}
