package com.lms.service;

import com.lms.requestdto.CertificateRequest;
import com.lms.entity.Certificate;
import com.lms.response.ApiResponse;

public interface ICertificationService {
    ApiResponse<Certificate> generateCertificate(CertificateRequest request, String userId);

    ApiResponse<Certificate> getCertificate(String courseId, String userId);

    ApiResponse<Object> getUserCertificates(String userId, int page, int size);
}
