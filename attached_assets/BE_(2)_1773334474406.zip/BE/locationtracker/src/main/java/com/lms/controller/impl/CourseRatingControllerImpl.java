package com.lms.rating.controller.impl;

import com.lms.config.UserContextHolder;
import com.lms.entity.CourseRating;
import com.lms.rating.controller.ICourseRatingController;
import com.lms.rating.dto.CourseRatingRequest;
import com.lms.rating.service.ICourseRatingService;
import com.lms.response.ApiResponse;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1")
public class CourseRatingControllerImpl implements ICourseRatingController {

    @Autowired
    private ICourseRatingService ratingService;

    @Override
    @PostMapping("/ratings")
    @PreAuthorize("hasRole('LEARNER')")
    public ApiResponse<CourseRating> addOrUpdateRating(@Valid @RequestBody CourseRatingRequest request) {
        String userId = UserContextHolder.getUserDto().getId();
        return ratingService.addOrUpdateRating(request, userId);
    }

    @Override
    @GetMapping("/courses/{courseId}/ratings")
    public ApiResponse<Object> getCourseRatings(
            @PathVariable String courseId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        return ratingService.getCourseRatings(courseId, page, size);
    }

    @Override
    @GetMapping("/courses/{courseId}/ratings/average")
    public ApiResponse<Double> getCourseAverageRating(@PathVariable String courseId) {
        return ratingService.getCourseAverageRating(courseId);
    }
}
