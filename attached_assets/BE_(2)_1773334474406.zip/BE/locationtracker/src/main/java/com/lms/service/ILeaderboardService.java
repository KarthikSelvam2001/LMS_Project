package com.lms.service;

import com.lms.response.ApiResponse;

public interface ILeaderboardService {
    ApiResponse<String> addPoints(String userId, int points);

    ApiResponse<Object> getTopLearners(int page, int size);

    ApiResponse<Object> getUserRank(String userId);
}
