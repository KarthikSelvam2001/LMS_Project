package com.lms.service.impl;

import com.lms.entity.Lesson;
import com.lms.entity.Module;
import com.lms.entity.Course;
import com.lms.repository.ICourseRepository;
import com.lms.repository.IModuleRepository;
import com.lms.requestdto.LessonRequest;
import com.lms.repository.ILessonRepository;
import com.lms.service.ILessonService;
import com.lms.response.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class LessonServiceImpl implements ILessonService {

    @Autowired
    private ILessonRepository lessonRepository;

    @Autowired
    private IModuleRepository moduleRepository;

    @Autowired
    private ICourseRepository courseRepository;

    private Course checkCourseAuth(String courseId, String trainerId) {
        Course course = courseRepository.findByIdAndIsDeletedFalse(courseId).orElse(null);
        if (course != null && course.getTrainerId().equals(trainerId)) {
            return course;
        }
        return null;
    }

    @Override
    public ApiResponse<Lesson> createLesson(String moduleId, LessonRequest request, String trainerId) {
        Module module = moduleRepository.findById(moduleId).orElse(null);
        if (module == null || module.getDeleted())
            return ApiResponse.error(404, "Module not found");

        if (checkCourseAuth(module.getCourseId(), trainerId) == null) {
            return ApiResponse.error(403, "Not authorized");
        }

        Lesson lesson = new Lesson();
        lesson.setModuleId(moduleId);
        lesson.setTitle(request.getTitle());
        lesson.setDescription(request.getDescription());
        lesson.setVideoUrl(request.getVideoUrl());
        lesson.setThumbnail(request.getThumbnail());
        lesson.setDuration(request.getDuration() != null ? request.getDuration() : 0);
        lesson.setOrder(request.getOrder());
        lesson.setCreatedBy(trainerId);
        lesson.setUpdatedBy(trainerId);
        lesson.setCreatedAt(LocalDateTime.now());
        lesson.setUpdatedAt(LocalDateTime.now());

        return ApiResponse.success(lessonRepository.save(lesson));
    }

    @Override
    public ApiResponse<Lesson> updateLesson(String lessonId, LessonRequest request, String trainerId) {
        Lesson lesson = lessonRepository.findById(lessonId).orElse(null);
        if (lesson == null || lesson.getDeleted())
            return ApiResponse.error(404, "Lesson not found");

        Module module = moduleRepository.findById(lesson.getModuleId()).orElse(null);
        if (module == null || module.getDeleted())
            return ApiResponse.error(404, "Module not found");

        if (checkCourseAuth(module.getCourseId(), trainerId) == null) {
            return ApiResponse.error(403, "Not authorized");
        }

        lesson.setTitle(request.getTitle());
        lesson.setDescription(request.getDescription());
        lesson.setVideoUrl(request.getVideoUrl());
        lesson.setThumbnail(request.getThumbnail());
        lesson.setDuration(request.getDuration() != null ? request.getDuration() : 0);
        lesson.setOrder(request.getOrder());
        lesson.setUpdatedBy(trainerId);
        lesson.setUpdatedAt(LocalDateTime.now());

        return ApiResponse.success(lessonRepository.save(lesson));
    }

    @Override
    public ApiResponse<String> deleteLesson(String lessonId, String trainerId) {
        Lesson lesson = lessonRepository.findById(lessonId).orElse(null);
        if (lesson == null || lesson.getDeleted())
            return ApiResponse.error(404, "Lesson not found");

        Module module = moduleRepository.findById(lesson.getModuleId()).orElse(null);
        if (module != null && !module.getDeleted()) {
            if (checkCourseAuth(module.getCourseId(), trainerId) == null) {
                return ApiResponse.error(403, "Not authorized");
            }
        }

        lesson.setDeleted(true);
        lesson.setUpdatedBy(trainerId);
        lesson.setUpdatedAt(LocalDateTime.now());
        lessonRepository.save(lesson);

        return ApiResponse.success("Lesson deleted successfully");
    }

    @Override
    public ApiResponse<List<Lesson>> getModuleLessons(String moduleId) {
        return ApiResponse.success(lessonRepository.findByModuleIdAndIsDeletedFalseOrderByOrderAsc(moduleId));
    }
}
