package com.lms.repository;

import com.lms.entity.Attendance;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface IAttendanceRepository extends MongoRepository<Attendance, String> {
    Optional<Attendance> findByUserIdAndLessonIdAndIsDeletedFalse(String userId, String lessonId);

    Page<Attendance> findByUserIdAndCourseIdAndIsDeletedFalse(String userId, String courseId, Pageable pageable);

    long countByUserIdAndCourseIdAndIsDeletedFalse(String userId, String courseId);
}
