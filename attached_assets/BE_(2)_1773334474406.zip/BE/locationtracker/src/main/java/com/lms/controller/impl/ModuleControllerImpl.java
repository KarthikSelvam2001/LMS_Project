package com.lms.module.controller.impl;

import com.lms.config.UserContextHolder;
import com.lms.entity.Module;
import com.lms.module.controller.IModuleController;
import com.lms.module.dto.ModuleRequest;
import com.lms.module.service.IModuleService;
import com.lms.response.ApiResponse;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1")
public class ModuleControllerImpl implements IModuleController {

    @Autowired
    private IModuleService moduleService;

    @Override
    @PostMapping("/courses/{courseId}/modules")
    @PreAuthorize("hasRole('TRAINER') or hasRole('ADMIN')")
    public ApiResponse<Module> createModule(@PathVariable String courseId, @Valid @RequestBody ModuleRequest request) {
        String trainerId = UserContextHolder.getUserDto().getId();
        return moduleService.createModule(courseId, request, trainerId);
    }

    @Override
    @PutMapping("/modules/{moduleId}")
    @PreAuthorize("hasRole('TRAINER') or hasRole('ADMIN')")
    public ApiResponse<Module> updateModule(@PathVariable String moduleId, @Valid @RequestBody ModuleRequest request) {
        String trainerId = UserContextHolder.getUserDto().getId();
        return moduleService.updateModule(moduleId, request, trainerId);
    }

    @Override
    @DeleteMapping("/modules/{moduleId}")
    @PreAuthorize("hasRole('TRAINER') or hasRole('ADMIN')")
    public ApiResponse<String> deleteModule(@PathVariable String moduleId) {
        String trainerId = UserContextHolder.getUserDto().getId();
        return moduleService.deleteModule(moduleId, trainerId);
    }

    @Override
    @GetMapping("/courses/{courseId}/modules")
    public ApiResponse<List<Module>> getCourseModules(@PathVariable String courseId) {
        return moduleService.getCourseModules(courseId);
    }
}
