package com.lms.repository;

import com.lms.entity.QuizAttempt;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface IQuizAttemptRepository extends MongoRepository<QuizAttempt, String> {
    List<QuizAttempt> findByUserIdAndQuizId(String userId, String quizId);

    Optional<QuizAttempt> findTopByUserIdAndQuizIdOrderByAttemptNumberDesc(String userId, String quizId);
}
