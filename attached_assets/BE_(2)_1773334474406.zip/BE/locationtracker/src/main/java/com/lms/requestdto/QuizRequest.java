package com.lms.requestdto;

import com.lms.entity.Quiz.Question;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;
import java.util.List;

@Data
public class QuizRequest {
    @NotEmpty(message = "Questions cannot be empty")
    private List<Question> questions;

    public List<Question> getQuestions() {
        return questions;
    }

    public void setQuestions(List<Question> questions) {
        this.questions = questions;
    }
}
