package com.lms.service;

import com.lms.requestdto.*;
import com.lms.response.ApiResponse;
import com.lms.entity.User;
import jakarta.servlet.http.HttpSession;

import java.util.Map;
import java.util.List;

public interface AuthService {
    ApiResponse<Object> signup(SignupRequest request, HttpSession session);

    ApiResponse<Object> verifyOtpAndCreateUser(VerifyOtpRequest request, HttpSession session);

    ApiResponse<Object> login(LoginRequest request, HttpSession session);

    ApiResponse<String> forgotPassword(ForgotPasswordRequest request);

    ApiResponse<String> resetPassword(ResetPasswordRequest request);

    ApiResponse<String> changePassword(String email, ChangePasswordRequest request);

    ApiResponse<Object> refreshToken(TokenDTO tokenDTO, HttpSession session);

    // ApiResponse<Object> googleLogin(String code, HttpSession session);
    ApiResponse<Object> googleLogin(Map<String, String> googleRequest, HttpSession session);

    User getUser(String username);

    ApiResponse<Object> debugUsers();

    ApiResponse<Object> getAllUsers();

    ApiResponse<Object> updateUserRole(String userId, List<String> roles);

    ApiResponse<Object> updateProfile(UpdateProfileRequest request);

    ApiResponse<Object> getTrainers();
}
