package com.lms.service;

import com.lms.response.ApiResponse;

public interface IDashboardService {
    ApiResponse<Object> getLearnerDashboard(String userId);

    ApiResponse<Object> getTrainerDashboard(String trainerId);

    ApiResponse<Object> getAdminDashboard();
}
