package com.lms.repository;

import com.lms.entity.Enrollment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface IEnrollmentRepository extends MongoRepository<Enrollment, String> {
    Optional<Enrollment> findByUserIdAndCourseIdAndIsDeletedFalse(String userId, String courseId);

    Page<Enrollment> findByUserIdAndIsDeletedFalse(String userId, Pageable pageable);

    Page<Enrollment> findByCourseIdAndIsDeletedFalse(String courseId, Pageable pageable);

    long countByUserIdAndIsDeletedFalse(String userId);

    long countByUserIdAndCompletedTrueAndIsDeletedFalse(String userId);

    long countByIsDeletedFalse();

    java.util.List<Enrollment> findByUserIdAndIsDeletedFalse(String userId);
}
