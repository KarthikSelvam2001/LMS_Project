package com.lms.repository;

import com.lms.entity.Module;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IModuleRepository extends MongoRepository<Module, String> {
    List<Module> findByCourseIdAndIsDeletedFalseOrderByOrderAsc(String courseId);
}
