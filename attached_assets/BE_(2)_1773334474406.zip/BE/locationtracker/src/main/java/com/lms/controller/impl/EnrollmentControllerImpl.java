package com.lms.enrollment.controller.impl;

import com.lms.config.UserContextHolder;
import com.lms.enrollment.controller.IEnrollmentController;
import com.lms.enrollment.dto.EnrollmentRequest;
import com.lms.enrollment.service.IEnrollmentService;
import com.lms.entity.Enrollment;
import com.lms.response.ApiResponse;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1")
public class EnrollmentControllerImpl implements IEnrollmentController {

    @Autowired
    private IEnrollmentService enrollmentService;

    @Override
    @PostMapping("/enrollments")
    @PreAuthorize("hasRole('LEARNER')")
    public ApiResponse<Enrollment> enrollUser(@Valid @RequestBody EnrollmentRequest request) {
        String userId = UserContextHolder.getUserDto().getId();
        return enrollmentService.enrollUser(request, userId);
    }

    @Override
    @GetMapping("/courses/{courseId}/my-enrollment")
    @PreAuthorize("hasRole('LEARNER')")
    public ApiResponse<Enrollment> getEnrollment(@PathVariable String courseId) {
        String userId = UserContextHolder.getUserDto().getId();
        return enrollmentService.getEnrollment(courseId, userId);
    }

    @Override
    @GetMapping("/my-enrollments")
    @PreAuthorize("hasRole('LEARNER')")
    public ApiResponse<Object> getUserEnrollments(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        String userId = UserContextHolder.getUserDto().getId();
        return enrollmentService.getUserEnrollments(userId, page, size);
    }

    @Override
    @GetMapping("/courses/{courseId}/enrollments")
    @PreAuthorize("hasRole('TRAINER') or hasRole('ADMIN')")
    public ApiResponse<Object> getCourseEnrollments(
            @PathVariable String courseId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        String trainerId = UserContextHolder.getUserDto().getId();
        return enrollmentService.getCourseEnrollments(courseId, trainerId, page, size);
    }
}
