package com.lms.rating.controller;

import com.lms.entity.CourseRating;
import com.lms.rating.dto.CourseRatingRequest;
import com.lms.response.ApiResponse;
import jakarta.validation.Valid;

public interface ICourseRatingController {
    ApiResponse<CourseRating> addOrUpdateRating(@Valid CourseRatingRequest request);

    ApiResponse<Object> getCourseRatings(String courseId, int page, int size);

    ApiResponse<Double> getCourseAverageRating(String courseId);
}
