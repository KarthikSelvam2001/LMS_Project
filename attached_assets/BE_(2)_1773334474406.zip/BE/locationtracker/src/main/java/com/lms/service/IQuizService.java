package com.lms.service;

import com.lms.requestdto.QuizAttemptRequest;
import com.lms.requestdto.QuizRequest;
import com.lms.entity.Quiz;
import com.lms.entity.QuizAttempt;
import com.lms.response.ApiResponse;

public interface IQuizService {
    ApiResponse<Quiz> createOrUpdateQuiz(String lessonId, QuizRequest request, String trainerId);

    ApiResponse<Quiz> getQuizByLesson(String lessonId);

    ApiResponse<String> deleteQuiz(String quizId, String trainerId);

    ApiResponse<QuizAttempt> submitQuizAttempt(String quizId, QuizAttemptRequest request, String userId);

    ApiResponse<Object> getUserQuizAttempts(String quizId, String userId);
}
