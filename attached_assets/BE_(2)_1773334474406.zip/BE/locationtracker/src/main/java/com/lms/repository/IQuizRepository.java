package com.lms.repository;

import com.lms.entity.Quiz;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface IQuizRepository extends MongoRepository<Quiz, String> {
    Optional<Quiz> findByLessonIdAndIsDeletedFalse(String lessonId);
}
