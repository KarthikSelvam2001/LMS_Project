package com.lms.module.controller;

import com.lms.entity.Module;
import com.lms.module.dto.ModuleRequest;
import com.lms.response.ApiResponse;
import jakarta.validation.Valid;

import java.util.List;

public interface IModuleController {
    ApiResponse<Module> createModule(String courseId, @Valid ModuleRequest request);

    ApiResponse<Module> updateModule(String moduleId, @Valid ModuleRequest request);

    ApiResponse<String> deleteModule(String moduleId);

    ApiResponse<List<Module>> getCourseModules(String courseId);
}
