package com.lms.controller.impl;

import com.lms.config.UserContextHolder;
import com.lms.constant.GeneralConstant;
import com.lms.controller.AuthController;
import com.lms.requestdto.*;
import com.lms.response.ApiResponse;
import com.lms.service.AuthService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.List;
import org.springframework.security.access.prepost.PreAuthorize;

@RestController
@RequestMapping(GeneralConstant.AUTH_BASE)
@Validated
public class AuthControllerImpl implements AuthController {

    private static final Logger logger = LoggerFactory.getLogger(AuthControllerImpl.class);

    @Autowired
    private AuthService authService;

    @Override
    @PostMapping("/signup")
    public ApiResponse<Object> signup(@RequestBody SignupRequest request, HttpSession session) {
        logger.info("Signup request received for email: {}", request.getEmail());
        ApiResponse<Object> response = authService.signup(request, session);
        logger.info("Signup response for email {}: {}", request.getEmail(), response.getStatusMessage());
        return response;
    }

    @Override
    @PostMapping("/verify-otp")
    public ApiResponse<Object> verifyOtp(@Valid @RequestBody VerifyOtpRequest request, HttpSession session) {
        logger.info("Verify OTP request received for email: {}", request.getEmail());
        ApiResponse<Object> response = authService.verifyOtpAndCreateUser(request, session);
        logger.info("Verify OTP response for email {}: {}", request.getEmail(), response.getStatusMessage());
        return response;
    }

    @Override
    @PostMapping("/login")
    public ApiResponse<Object> login(@Valid @RequestBody LoginRequest request, HttpSession session) {
        logger.info("Login request received for email: {}", request.getEmail());
        ApiResponse<Object> response = authService.login(request, session);
        logger.info("Login response for email {}: {}", request.getEmail(), response.getStatusMessage());
        return response;
    }

    @Override
    @PostMapping("/forgot-password")
    public ApiResponse<String> forgotPassword(@Valid @RequestBody ForgotPasswordRequest request) {
        logger.info("Forgot password request received for email: {}", request.getEmail());
        ApiResponse<String> response = authService.forgotPassword(request);
        logger.info("Forgot password response for email {}: {}", request.getEmail(), response.getStatusMessage());
        return response;
    }

    @Override
    @PostMapping("/reset-password")
    public ApiResponse<String> resetPassword(@Valid @RequestBody ResetPasswordRequest request) {
        logger.info("Reset password request received");
        ApiResponse<String> response = authService.resetPassword(request);
        logger.info("Reset password response: {}", response.getStatusMessage());
        return response;
    }

    @Override
    @PostMapping("/change-password")
    public ApiResponse<String> changePassword(@Valid @RequestBody ChangePasswordRequest request) {
        String email = UserContextHolder.getUserDto().getEmail();
        logger.info("Change password request received for email: {}", email);
        ApiResponse<String> response = authService.changePassword("admin@lms.com", request);
        logger.info("Change password response for email {}: {}", email, response.getStatusMessage());
        return response;
    }

    @Override
    @PostMapping("/refresh")
    public ApiResponse<Object> refreshToken(TokenDTO tokenDTO, HttpSession session) {
        logger.info("Refresh token request received");
        ApiResponse<Object> response = authService.refreshToken(tokenDTO, session);
        logger.info("Refresh token response: {}", response.getStatusMessage());
        return response;
    }

    @PostMapping("/google-login")
    public ApiResponse<Object> googleLogin(Map<String, String> googleRequest, HttpSession session) {
        logger.info("Google login request received");
        ApiResponse<Object> response = authService.googleLogin(googleRequest, session);
        logger.info("Google login response: {}", response.getStatusMessage());
        return response;
    }

    @Override
    @GetMapping("/debug/users")
    public ApiResponse<Object> debugUsers() {
        return authService.debugUsers();
    }

    @Override
    @GetMapping("/users")
    @PreAuthorize("hasRole('ADMIN')")
    public ApiResponse<Object> getAllUsers() {
        logger.info("Admin request to fetch all users");
        return authService.getAllUsers();
    }

    @Override
    @PutMapping("/users/{userId}/role")
    @PreAuthorize("hasRole('ADMIN')")
    public ApiResponse<Object> updateUserRole(@PathVariable String userId, @RequestBody List<String> roles) {
        logger.info("Admin request to update roles for user: {}", userId);
        return authService.updateUserRole(userId, roles);
    }

    @Override
    @PutMapping("/profile")
    public ApiResponse<Object> updateProfile(@Valid @RequestBody UpdateProfileRequest request) {
        logger.info("Profile update request received for user: {}", UserContextHolder.getUserDto().getId());
        return authService.updateProfile(request);
    }

    @Override
    @GetMapping("/trainers")
    public ApiResponse<Object> getTrainers() {
        logger.info("Request to fetch all trainers");
        return authService.getTrainers();
    }
}
