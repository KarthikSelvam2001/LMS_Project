package com.lms.entity;

public enum UserRole {
    ADMIN,
    TRAINER,
    LEARNER
}
