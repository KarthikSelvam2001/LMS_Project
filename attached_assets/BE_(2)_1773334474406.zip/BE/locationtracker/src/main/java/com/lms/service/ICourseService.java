package com.lms.service;

import com.lms.requestdto.CourseRequest;
import com.lms.entity.Course;
import com.lms.response.ApiResponse;

public interface ICourseService {
    ApiResponse<Course> createCourse(CourseRequest request, String trainerId);

    ApiResponse<Course> updateCourse(String courseId, CourseRequest request, String trainerId);

    ApiResponse<String> deleteCourse(String courseId, String trainerId);

    ApiResponse<Course> getCourseById(String courseId);

    ApiResponse<Object> getAllCourses(int page, int size);

    ApiResponse<Object> getCoursesByTrainer(String trainerId, int page, int size);

    ApiResponse<String> publishCourse(String courseId, String trainerId);

    ApiResponse<String> unpublishCourse(String courseId, String trainerId);

    ApiResponse<Object> getPublishedCourses(int page, int size);
}
