package com.lms.controller;

import com.lms.requestdto.CourseRequest;
import com.lms.entity.Course;
import com.lms.response.ApiResponse;
import jakarta.validation.Valid;

public interface ICourseController {
    ApiResponse<Course> createCourse(@Valid CourseRequest request);

    ApiResponse<Course> updateCourse(String courseId, @Valid CourseRequest request);

    ApiResponse<String> deleteCourse(String courseId);

    ApiResponse<Course> getCourse(String courseId);

    ApiResponse<Object> getAllCourses(int page, int size);

    ApiResponse<Object> getCoursesByTrainer(String trainerId, int page, int size);

    ApiResponse<Object> getMyCourses(int page, int size);

    ApiResponse<String> publishCourse(String courseId);

    ApiResponse<String> unpublishCourse(String courseId);

    ApiResponse<Object> getPublishedCourses(int page, int size);
}
