package com.lms.leaderboard.controller;

import com.lms.response.ApiResponse;

public interface ILeaderboardController {
    ApiResponse<Object> getTopLearners(int page, int size);

    ApiResponse<Object> getMyRank();
}
