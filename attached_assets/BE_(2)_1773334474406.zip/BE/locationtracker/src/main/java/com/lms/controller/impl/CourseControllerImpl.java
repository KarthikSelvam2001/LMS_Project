package com.lms.controller.impl;

import com.lms.config.UserContextHolder;
import com.lms.controller.ICourseController;
import com.lms.requestdto.CourseRequest;
import com.lms.entity.Course;
import com.lms.service.ICourseService;
import com.lms.response.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/v1/courses")
public class CourseControllerImpl implements ICourseController {

    @Autowired
    private ICourseService courseService;

    @Override
    @PostMapping
    @PreAuthorize("hasRole('TRAINER') or hasRole('ADMIN')")
    public ApiResponse<Course> createCourse(@Valid @RequestBody CourseRequest request) {
        String trainerId = UserContextHolder.getUserDto().getId();
        return courseService.createCourse(request, trainerId);
    }

    @Override
    @PutMapping("/{courseId}")
    @PreAuthorize("hasRole('TRAINER') or hasRole('ADMIN')")
    public ApiResponse<Course> updateCourse(@PathVariable String courseId, @Valid @RequestBody CourseRequest request) {
        String trainerId = UserContextHolder.getUserDto().getId();
        return courseService.updateCourse(courseId, request, trainerId);
    }

    @Override
    @DeleteMapping("/{courseId}")
    @PreAuthorize("hasRole('TRAINER') or hasRole('ADMIN')")
    public ApiResponse<String> deleteCourse(@PathVariable String courseId) {
        String trainerId = UserContextHolder.getUserDto().getId();
        return courseService.deleteCourse(courseId, trainerId);
    }

    @Override
    @GetMapping("/{courseId}")
    public ApiResponse<Course> getCourse(@PathVariable String courseId) {
        return courseService.getCourseById(courseId);
    }

    @Override
    @GetMapping
    public ApiResponse<Object> getAllCourses(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        return courseService.getAllCourses(page, size);
    }

    @Override
    @GetMapping("/published")
    public ApiResponse<Object> getPublishedCourses(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        return courseService.getPublishedCourses(page, size);
    }

    @Override
    @GetMapping("/trainer/{trainerId}")
    @PreAuthorize("hasRole('TRAINER') or hasRole('ADMIN')")
    public ApiResponse<Object> getCoursesByTrainer(
            @PathVariable String trainerId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        return courseService.getCoursesByTrainer(trainerId, page, size);
    }

    @Override
    @GetMapping("/my-courses")
    @PreAuthorize("hasRole('TRAINER')")
    public ApiResponse<Object> getMyCourses(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        String trainerId = UserContextHolder.getUserDto().getId();
        return courseService.getCoursesByTrainer(trainerId, page, size);
    }

    @Override
    @PatchMapping("/{courseId}/publish")
    @PreAuthorize("hasRole('TRAINER') or hasRole('ADMIN')")
    public ApiResponse<String> publishCourse(@PathVariable String courseId) {
        String trainerId = UserContextHolder.getUserDto().getId();
        return courseService.publishCourse(courseId, trainerId);
    }

    @Override
    @PatchMapping("/{courseId}/unpublish")
    @PreAuthorize("hasRole('TRAINER') or hasRole('ADMIN')")
    public ApiResponse<String> unpublishCourse(@PathVariable String courseId) {
        String trainerId = UserContextHolder.getUserDto().getId();
        return courseService.unpublishCourse(courseId, trainerId);
    }
}
