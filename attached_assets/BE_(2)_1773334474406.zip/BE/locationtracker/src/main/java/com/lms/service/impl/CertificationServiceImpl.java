package com.lms.service.impl;

import com.lms.requestdto.CertificateRequest;
import com.lms.repository.ICertificateRepository;
import com.lms.service.ICertificationService;
import com.lms.responsedto.PageResponse;
import com.lms.repository.IEnrollmentRepository;
import com.lms.entity.Certificate;
import com.lms.entity.Enrollment;
import com.lms.response.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;

@Service
public class CertificationServiceImpl implements ICertificationService {

    @Autowired
    private ICertificateRepository certificateRepository;
    @Autowired
    private IEnrollmentRepository enrollmentRepository;

    @Override
    public ApiResponse<Certificate> generateCertificate(CertificateRequest request, String userId) {
        Enrollment enrollment = enrollmentRepository
                .findByUserIdAndCourseIdAndIsDeletedFalse(userId, request.getCourseId()).orElse(null);
        if (enrollment == null) {
            return ApiResponse.error(404, "Enrollment not found");
        }

        // Ensure 100% progress before generating cert
        if (enrollment.getProgress() < 100.0) {
            return ApiResponse.error(400, "Course is not fully completed yet");
        }

        Optional<Certificate> existingOpt = certificateRepository.findByUserIdAndCourseIdAndIsDeletedFalse(userId,
                request.getCourseId());
        if (existingOpt.isPresent()) {
            return ApiResponse.success(existingOpt.get()); // Return already generated one
        }

        Certificate cert = new Certificate();
        cert.setUserId(userId);
        cert.setCourseId(request.getCourseId());
        cert.setIssuedDate(LocalDateTime.now());
        // Mocking a blob url generation for now
        cert.setCertificateUrl("https://lms-cert.mock.blob.core/certs/" + UUID.randomUUID().toString() + ".pdf");
        cert.setCreatedBy(userId);
        cert.setUpdatedBy(userId);
        cert.setCreatedAt(LocalDateTime.now());
        cert.setUpdatedAt(LocalDateTime.now());

        return ApiResponse.success(certificateRepository.save(cert));
    }

    @Override
    public ApiResponse<Certificate> getCertificate(String courseId, String userId) {
        Certificate cert = certificateRepository.findByUserIdAndCourseIdAndIsDeletedFalse(userId, courseId)
                .orElse(null);
        if (cert == null)
            return ApiResponse.error(404, "Certificate not found");
        return ApiResponse.success(cert);
    }

    @Override
    public ApiResponse<Object> getUserCertificates(String userId, int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        Page<Certificate> certPage = certificateRepository.findByUserIdAndIsDeletedFalse(userId, pageable);
        return ApiResponse.success(buildPageResponse(certPage));
    }

    private <T> PageResponse<T> buildPageResponse(Page<T> page) {
        PageResponse<T> response = new PageResponse<>();
        response.setContent(page.getContent());
        response.setPageNumber(page.getNumber());
        response.setPageSize(page.getSize());
        response.setTotalElements(page.getTotalElements());
        response.setTotalPages(page.getTotalPages());
        response.setLast(page.isLast());
        return response;
    }
}
