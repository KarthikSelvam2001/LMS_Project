package com.lms.requestdto;

import jakarta.validation.constraints.NotEmpty;
import lombok.Data;
import java.util.Map;

@Data
public class QuizAttemptRequest {
    // Map of question -> selected answer
    @NotEmpty(message = "Answers cannot be empty")
    private Map<String, String> answers;

    public Map<String, String> getAnswers() {
        return answers;
    }

    public void setAnswers(Map<String, String> answers) {
        this.answers = answers;
    }
}
