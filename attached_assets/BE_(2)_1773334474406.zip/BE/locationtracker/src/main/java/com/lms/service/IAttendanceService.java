package com.lms.service;

import com.lms.requestdto.AttendanceRequest;
import com.lms.entity.Attendance;
import com.lms.response.ApiResponse;

public interface IAttendanceService {
    ApiResponse<Attendance> markAttendance(AttendanceRequest request, String userId);

    ApiResponse<Object> getCourseAttendance(String courseId, String userId, int page, int size);

    ApiResponse<Double> getCourseProgress(String courseId, String userId);
}
