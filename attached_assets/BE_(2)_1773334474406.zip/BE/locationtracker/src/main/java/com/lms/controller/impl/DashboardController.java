package com.lms.controller.impl;

import com.lms.service.IDashboardService;
import com.lms.config.UserContextHolder;
import com.lms.responsedto.DashboardAnalyticsResponse;
import com.lms.repository.UserRepository;
import com.lms.repository.ICourseRepository;
import com.lms.repository.IEnrollmentRepository;
import com.lms.entity.Course;
import com.lms.entity.Enrollment;
import com.lms.entity.User;
import com.lms.entity.UserRole;
import com.lms.response.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v1/dashboard")
public class DashboardController {

        @Autowired
        private IDashboardService dashboardService;

        @Autowired
        private UserRepository userRepository;

        @Autowired
        private ICourseRepository courseRepository;

        @Autowired
        private IEnrollmentRepository enrollmentRepository;

        @GetMapping("/learner")
        // @PreAuthorize("hasRole('LEARNER')")
        public ApiResponse<Object> getLearnerDashboard() {
                String userId = UserContextHolder.getUserDto().getId();
                return dashboardService.getLearnerDashboard(userId);
        }

        @GetMapping("/trainer")
        // @PreAuthorize("hasRole('TRAINER')")
        public ApiResponse<Object> getTrainerDashboard() {
                String userId = UserContextHolder.getUserDto().getId();
                return dashboardService.getTrainerDashboard(userId);
        }

        @GetMapping("/admin")
        // @PreAuthorize("hasRole('ADMIN')")
        public ApiResponse<Object> getAdminDashboard() {
                return dashboardService.getAdminDashboard();
        }

        @GetMapping("/analytics")
        public ApiResponse<Object> getDashboardAnalytics() {
                String userId = UserContextHolder.getUserDto().getId();
                List<String> roles = UserContextHolder.getUserDto().getRoles();
                boolean isAdmin = roles.contains(UserRole.ADMIN.name());
                boolean isTrainer = roles.contains(UserRole.TRAINER.name());

                DashboardAnalyticsResponse response = new DashboardAnalyticsResponse();
                List<Course> allCourses;
                List<Enrollment> allEnrollments;

                if (isAdmin) {
                        allCourses = courseRepository.findAll();
                        allEnrollments = enrollmentRepository.findAll();

                        response.setTotalCourses(allCourses.size());
                        response.setTotalLearners(userRepository.findAll().stream()
                                        .filter(u -> u.getRoles() != null
                                                        && u.getRoles().contains(UserRole.LEARNER.name()))
                                        .count());
                        response.setTotalTrainers(userRepository.findAll().stream()
                                        .filter(u -> u.getRoles() != null
                                                        && u.getRoles().contains(UserRole.TRAINER.name()))
                                        .count());
                        response.setTotalEnrollments(allEnrollments.size());
                } else if (isTrainer) {
                        allCourses = courseRepository.findAll().stream()
                                        .filter(c -> userId.equals(c.getTrainerId()))
                                        .collect(Collectors.toList());

                        List<String> myCourseIds = allCourses.stream().map(Course::getId).collect(Collectors.toList());
                        allEnrollments = enrollmentRepository.findAll().stream()
                                        .filter(e -> myCourseIds.contains(e.getCourseId()))
                                        .collect(Collectors.toList());

                        response.setTotalCourses(allCourses.size());
                        response.setTotalEnrollments(allEnrollments.size());
                        response.setTotalLearners(allEnrollments.stream()
                                        .map(Enrollment::getUserId)
                                        .distinct()
                                        .count());
                        response.setTotalTrainers(1); // Just themselves
                } else {
                        // Learner
                        allEnrollments = enrollmentRepository.findAll().stream()
                                        .filter(e -> userId.equals(e.getUserId()))
                                        .collect(Collectors.toList());

                        allCourses = courseRepository.findAll(); // Platform total for discovery

                        response.setTotalCourses(allCourses.size());
                        response.setTotalEnrollments(allEnrollments.size());
                        response.setTotalLearners(userRepository.findAll().stream()
                                        .filter(u -> u.getRoles() != null
                                                        && u.getRoles().contains(UserRole.LEARNER.name()))
                                        .count());
                        response.setTotalTrainers(userRepository.findAll().stream()
                                        .filter(u -> u.getRoles() != null
                                                        && u.getRoles().contains(UserRole.TRAINER.name()))
                                        .count());
                }

                // Course Distribution By Category
                Map<String, Long> categoryCount = allCourses.stream()
                                .filter(c -> c.getCategory() != null)
                                .collect(Collectors.groupingBy(Course::getCategory, Collectors.counting()));

                List<DashboardAnalyticsResponse.PieChartData> courseDist = categoryCount.entrySet().stream()
                                .map(e -> new DashboardAnalyticsResponse.PieChartData(e.getKey(), e.getValue()))
                                .collect(Collectors.toList());

                response.setCourseDistributionData(courseDist);

                // Progress metrics
                long completed = allEnrollments.stream().filter(Enrollment::isCompleted).count();
                long inProgress = allEnrollments.stream().filter(e -> e.getProgressPercentage() > 0 && !e.isCompleted())
                                .count();
                long notStarted = allEnrollments.stream().filter(e -> e.getProgressPercentage() == 0).count();

                response.setLearnerProgressData(Arrays.asList(
                                new DashboardAnalyticsResponse.PieChartData("Completed", completed),
                                new DashboardAnalyticsResponse.PieChartData("In Progress", inProgress),
                                new DashboardAnalyticsResponse.PieChartData("Not Started", notStarted)));

                return ApiResponse.success(response);
        }
}
