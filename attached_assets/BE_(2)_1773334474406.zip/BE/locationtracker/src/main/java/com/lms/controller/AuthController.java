package com.lms.controller;

import com.lms.requestdto.*;
import com.lms.response.ApiResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.web.bind.annotation.RequestBody;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import java.util.Map;
import java.util.List;

public interface AuthController {
    ApiResponse<Object> signup(@Valid @RequestBody SignupRequest request, HttpSession session);

    ApiResponse<Object> verifyOtp(@Valid @RequestBody VerifyOtpRequest request, HttpSession session);

    ApiResponse<Object> googleLogin(Map<String, String> googleRequest, HttpSession session);

    @GetMapping("/debug/users")
    ApiResponse<Object> debugUsers();

    ApiResponse<Object> login(@Valid @RequestBody LoginRequest request, HttpSession session);

    ApiResponse<String> forgotPassword(@Valid @RequestBody ForgotPasswordRequest request);

    ApiResponse<String> resetPassword(@Valid @RequestBody ResetPasswordRequest request);

    ApiResponse<String> changePassword(@Valid @RequestBody ChangePasswordRequest request);

    ApiResponse<Object> refreshToken(@Valid @RequestBody TokenDTO tokenDTO, HttpSession session);

    ApiResponse<Object> getAllUsers();

    ApiResponse<Object> updateUserRole(String userId, List<String> roles);

    @PutMapping("/profile")
    ApiResponse<Object> updateProfile(@Valid @RequestBody UpdateProfileRequest request);

    @GetMapping("/trainers")
    ApiResponse<Object> getTrainers();
}
