package com.lms.repository;

import com.lms.entity.Course;
import com.lms.entity.CourseStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ICourseRepository extends MongoRepository<Course, String> {
    Optional<Course> findByIdAndIsDeletedFalse(String id);

    Page<Course> findByStatusAndIsDeletedFalse(CourseStatus status, Pageable pageable);

    Page<Course> findByTrainerIdAndIsDeletedFalse(String trainerId, Pageable pageable);

    @Query("{ 'title': { $regex: ?0, $options: 'i' }, 'isDeleted': false }")
    Page<Course> searchByTitle(String titleRegex, Pageable pageable);

    @Query("{ 'title': { $regex: ?0, $options: 'i' }, 'trainerId': ?1, 'isDeleted': false }")
    Page<Course> searchByTitleAndTrainer(String titleRegex, String trainerId, Pageable pageable);

    long countByTrainerIdAndIsDeletedFalse(String trainerId);

    long countByIsDeletedFalse();

    Page<Course> findByIsDeletedFalse(Pageable pageable);
}
