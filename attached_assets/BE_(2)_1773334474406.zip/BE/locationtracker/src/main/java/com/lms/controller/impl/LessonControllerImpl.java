package com.lms.lesson.controller.impl;

import com.lms.config.UserContextHolder;
import com.lms.entity.Lesson;
import com.lms.lesson.controller.ILessonController;
import com.lms.lesson.dto.LessonRequest;
import com.lms.lesson.service.ILessonService;
import com.lms.response.ApiResponse;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1")
public class LessonControllerImpl implements ILessonController {

    @Autowired
    private ILessonService lessonService;

    @Override
    @PostMapping("/modules/{moduleId}/lessons")
    @PreAuthorize("hasRole('TRAINER') or hasRole('ADMIN')")
    public ApiResponse<Lesson> createLesson(@PathVariable String moduleId, @Valid @RequestBody LessonRequest request) {
        String trainerId = UserContextHolder.getUserDto().getId();
        return lessonService.createLesson(moduleId, request, trainerId);
    }

    @Override
    @PutMapping("/lessons/{lessonId}")
    @PreAuthorize("hasRole('TRAINER') or hasRole('ADMIN')")
    public ApiResponse<Lesson> updateLesson(@PathVariable String lessonId, @Valid @RequestBody LessonRequest request) {
        String trainerId = UserContextHolder.getUserDto().getId();
        return lessonService.updateLesson(lessonId, request, trainerId);
    }

    @Override
    @DeleteMapping("/lessons/{lessonId}")
    @PreAuthorize("hasRole('TRAINER') or hasRole('ADMIN')")
    public ApiResponse<String> deleteLesson(@PathVariable String lessonId) {
        String trainerId = UserContextHolder.getUserDto().getId();
        return lessonService.deleteLesson(lessonId, trainerId);
    }

    @Override
    @GetMapping("/modules/{moduleId}/lessons")
    public ApiResponse<List<Lesson>> getModuleLessons(@PathVariable String moduleId) {
        return lessonService.getModuleLessons(moduleId);
    }
}
