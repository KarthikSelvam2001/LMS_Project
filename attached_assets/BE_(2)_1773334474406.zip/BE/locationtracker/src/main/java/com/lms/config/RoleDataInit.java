package com.lms.config;

import com.lms.entity.Role;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;

import jakarta.annotation.PostConstruct;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

@Component
public class RoleDataInit {

    private static final Logger logger = LoggerFactory.getLogger(RoleDataInit.class);

    @Autowired
    private MongoTemplate mongoTemplate;

    @PostConstruct
    public void initRoles() {
        logger.info("Checking and initializing default roles...");

        List<String> defaultRoles = Arrays.asList("ADMIN", "TRAINER", "LEARNER");

        for (String roleName : defaultRoles) {
            Query query = new Query(Criteria.where("name").is(roleName));
            Role existingRole = mongoTemplate.findOne(query, Role.class);

            if (existingRole == null) {
                logger.info("Role {} not found, creating...", roleName);
                Role role = new Role();
//                role.setId(roleName);
                role.setName(roleName.replace("ROLE_", ""));
                role.setCreatedBy("SYSTEM");
                role.setUpdatedBy("SYSTEM");
                role.setCreatedAt(LocalDateTime.now());
                role.setUpdatedAt(LocalDateTime.now());
                mongoTemplate.save(role);
            } else {
                logger.info("Role {} already exists, updating timestamp...", roleName);
                existingRole.setUpdatedAt(LocalDateTime.now());
                mongoTemplate.save(existingRole);
            }
        }

        logger.info("Roles initialization complete.");
    }
}
