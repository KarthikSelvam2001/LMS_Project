package com.lms.certification.controller;

import com.lms.certification.dto.CertificateRequest;
import com.lms.entity.Certificate;
import com.lms.response.ApiResponse;
import jakarta.validation.Valid;

public interface ICertificateController {
    ApiResponse<Certificate> generateCertificate(@Valid CertificateRequest request);

    ApiResponse<Certificate> getCertificate(String courseId);

    ApiResponse<Object> getUserCertificates(int page, int size);
}
