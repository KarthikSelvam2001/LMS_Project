package com.lms.service;

import com.lms.entity.Lesson;
import com.lms.requestdto.LessonRequest;
import com.lms.response.ApiResponse;

import java.util.List;

public interface ILessonService {
    ApiResponse<Lesson> createLesson(String moduleId, LessonRequest request, String trainerId);

    ApiResponse<Lesson> updateLesson(String lessonId, LessonRequest request, String trainerId);

    ApiResponse<String> deleteLesson(String lessonId, String trainerId);

    ApiResponse<List<Lesson>> getModuleLessons(String moduleId);
}
