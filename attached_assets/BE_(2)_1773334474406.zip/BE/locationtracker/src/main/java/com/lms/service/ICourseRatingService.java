package com.lms.service;

import com.lms.entity.CourseRating;
import com.lms.requestdto.CourseRatingRequest;
import com.lms.response.ApiResponse;

public interface ICourseRatingService {
    ApiResponse<CourseRating> addOrUpdateRating(CourseRatingRequest request, String userId);

    ApiResponse<Object> getCourseRatings(String courseId, int page, int size);

    ApiResponse<Double> getCourseAverageRating(String courseId);
}
