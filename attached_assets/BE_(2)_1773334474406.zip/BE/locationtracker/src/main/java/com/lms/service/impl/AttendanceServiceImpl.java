package com.lms.service.impl;

import com.lms.requestdto.AttendanceRequest;
import com.lms.repository.IAttendanceRepository;
import com.lms.service.IAttendanceService;
import com.lms.responsedto.PageResponse;
import com.lms.repository.ICourseRepository;
import com.lms.repository.IEnrollmentRepository;
import com.lms.entity.Attendance;
import com.lms.entity.Course;
import com.lms.entity.Enrollment;
import com.lms.entity.Lesson;
import com.lms.entity.Module;
import com.lms.repository.ILessonRepository;
import com.lms.repository.IModuleRepository;
import com.lms.response.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class AttendanceServiceImpl implements IAttendanceService {

    @Autowired
    private IAttendanceRepository attendanceRepository;
    @Autowired
    private ICourseRepository courseRepository;
    @Autowired
    private IEnrollmentRepository enrollmentRepository;
    @Autowired
    private ILessonRepository lessonRepository;
    @Autowired
    private IModuleRepository moduleRepository;

    @Override
    public ApiResponse<Attendance> markAttendance(AttendanceRequest request, String userId) {
        // Validate Course
        Course course = courseRepository.findByIdAndIsDeletedFalse(request.getCourseId()).orElse(null);
        if (course == null)
            return ApiResponse.error(404, "Course not found");

        // Validate Enrollment
        Enrollment enrollment = enrollmentRepository
                .findByUserIdAndCourseIdAndIsDeletedFalse(userId, request.getCourseId()).orElse(null);
        if (enrollment == null)
            return ApiResponse.error(403, "Not enrolled in this course");

        // Validate Lesson
        Lesson lesson = lessonRepository.findById(request.getLessonId()).orElse(null);
        if (lesson == null || lesson.getDeleted())
            return ApiResponse.error(404, "Lesson not found");

        // Create or get Attendance
        Optional<Attendance> existingOpt = attendanceRepository.findByUserIdAndLessonIdAndIsDeletedFalse(userId,
                request.getLessonId());
        Attendance attendance;
        if (existingOpt.isPresent()) {
            attendance = existingOpt.get();
        } else {
            attendance = new Attendance();
            attendance.setUserId(userId);
            attendance.setLessonId(request.getLessonId());
            attendance.setCourseId(request.getCourseId());
            attendance.setStatus("COMPLETED");
            attendance.setCreatedBy(userId);
            attendance.setCreatedAt(LocalDateTime.now());
        }

        attendance.setUpdatedBy(userId);
        attendance.setUpdatedAt(LocalDateTime.now());
        attendanceRepository.save(attendance);

        // Update Progress
        updateEnrollmentProgress(enrollment, request.getCourseId(), userId);

        return ApiResponse.success(attendance);
    }

    @Override
    public ApiResponse<Object> getCourseAttendance(String courseId, String userId, int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        Page<Attendance> attendancePage = attendanceRepository.findByUserIdAndCourseIdAndIsDeletedFalse(userId,
                courseId, pageable);
        return ApiResponse.success(buildPageResponse(attendancePage));
    }

    @Override
    public ApiResponse<Double> getCourseProgress(String courseId, String userId) {
        Enrollment enrollment = enrollmentRepository.findByUserIdAndCourseIdAndIsDeletedFalse(userId, courseId)
                .orElse(null);
        if (enrollment == null)
            return ApiResponse.error(404, "Enrollment not found");
        return ApiResponse.success(enrollment.getProgress());
    }

    private void updateEnrollmentProgress(Enrollment enrollment, String courseId, String userId) {
        // Find total lessons in course
        List<Module> modules = moduleRepository.findByCourseIdAndIsDeletedFalseOrderByOrderAsc(courseId);
        long totalLessons = 0;
        for (Module m : modules) {
            totalLessons += lessonRepository.findByModuleIdAndIsDeletedFalseOrderByOrderAsc(m.getId()).size();
        }

        long completedLessons = attendanceRepository.countByUserIdAndCourseIdAndIsDeletedFalse(userId, courseId);

        double progress = 0.0;
        if (totalLessons > 0) {
            progress = ((double) completedLessons / totalLessons) * 100;
        }

        enrollment.setProgress(progress);
        enrollment.setUpdatedAt(LocalDateTime.now());
        enrollmentRepository.save(enrollment);
    }

    private <T> PageResponse<T> buildPageResponse(Page<T> page) {
        PageResponse<T> response = new PageResponse<>();
        response.setContent(page.getContent());
        response.setPageNumber(page.getNumber());
        response.setPageSize(page.getSize());
        response.setTotalElements(page.getTotalElements());
        response.setTotalPages(page.getTotalPages());
        response.setLast(page.isLast());
        return response;
    }
}
