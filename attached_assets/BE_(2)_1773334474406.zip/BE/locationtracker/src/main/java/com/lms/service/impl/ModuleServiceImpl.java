package com.lms.service.impl;

import com.lms.entity.Module;
import com.lms.entity.Course;
import com.lms.repository.ICourseRepository;
import com.lms.requestdto.ModuleRequest;
import com.lms.repository.IModuleRepository;
import com.lms.service.IModuleService;
import com.lms.response.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class ModuleServiceImpl implements IModuleService {

    @Autowired
    private IModuleRepository moduleRepository;

    @Autowired
    private ICourseRepository courseRepository;

    @Override
    public ApiResponse<Module> createModule(String courseId, ModuleRequest request, String trainerId) {
        Course course = courseRepository.findByIdAndIsDeletedFalse(courseId).orElse(null);
        if (course == null)
            return ApiResponse.error(404, "Course not found");
        if (!course.getTrainerId().equals(trainerId))
            return ApiResponse.error(403, "Not authorized");

        Module module = new Module();
        module.setCourseId(courseId);
        module.setTitle(request.getTitle());
        module.setDescription(request.getDescription());
        module.setOrder(request.getOrder());
        module.setCreatedBy(trainerId);
        module.setUpdatedBy(trainerId);
        module.setCreatedAt(LocalDateTime.now());
        module.setUpdatedAt(LocalDateTime.now());

        Module saved = moduleRepository.save(module);

        // Update course module count
        course.setModulesCount(course.getModulesCount() != null ? course.getModulesCount() + 1 : 1);
        courseRepository.save(course);

        return ApiResponse.success(saved);
    }

    @Override
    public ApiResponse<Module> updateModule(String moduleId, ModuleRequest request, String trainerId) {
        Module module = moduleRepository.findById(moduleId).orElse(null);
        if (module == null || module.getDeleted())
            return ApiResponse.error(404, "Module not found");

        Course course = courseRepository.findById(module.getCourseId()).orElse(null);
        if (course == null || !course.getTrainerId().equals(trainerId))
            return ApiResponse.error(403, "Not authorized");

        module.setTitle(request.getTitle());
        module.setDescription(request.getDescription());
        module.setOrder(request.getOrder());
        module.setUpdatedBy(trainerId);
        module.setUpdatedAt(LocalDateTime.now());

        return ApiResponse.success(moduleRepository.save(module));
    }

    @Override
    public ApiResponse<String> deleteModule(String moduleId, String trainerId) {
        Module module = moduleRepository.findById(moduleId).orElse(null);
        if (module == null || module.getDeleted())
            return ApiResponse.error(404, "Module not found");

        Course course = courseRepository.findById(module.getCourseId()).orElse(null);
        if (course == null || !course.getTrainerId().equals(trainerId))
            return ApiResponse.error(403, "Not authorized");

        module.setDeleted(true);
        module.setUpdatedBy(trainerId);
        module.setUpdatedAt(LocalDateTime.now());
        moduleRepository.save(module);

        // Update course module count
        course.setModulesCount(Math.max(0, (course.getModulesCount() != null ? course.getModulesCount() : 0) - 1));
        courseRepository.save(course);

        return ApiResponse.success("Module deleted successfully");
    }

    @Override
    public ApiResponse<List<Module>> getCourseModules(String courseId) {
        return ApiResponse.success(moduleRepository.findByCourseIdAndIsDeletedFalseOrderByOrderAsc(courseId));
    }
}
