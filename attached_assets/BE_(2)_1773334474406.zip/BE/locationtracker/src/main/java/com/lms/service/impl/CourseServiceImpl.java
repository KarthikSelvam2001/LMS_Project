package com.lms.service.impl;

import com.lms.responsedto.PageResponse;
import com.lms.requestdto.CourseRequest;
import com.lms.entity.Course;
import com.lms.entity.CourseStatus;
import com.lms.repository.ICourseRepository;
import com.lms.service.ICourseService;
import com.lms.response.ApiResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class CourseServiceImpl implements ICourseService {

    private static final Logger logger = LoggerFactory.getLogger(CourseServiceImpl.class);

    @Autowired
    private ICourseRepository courseRepository;

    @Override
    public ApiResponse<Course> createCourse(CourseRequest request, String callerId) {
        logger.info("Creating course: {} by caller: {}", request.getTitle(), callerId);
        try {
            Course course = new Course();
            course.setTitle(request.getTitle());
            course.setDescription(request.getDescription());
            course.setThumbnail(request.getThumbnailUrl());
            course.setPrice(request.getPrice() != null ? request.getPrice() : 0.0);
            course.setStatus(CourseStatus.DRAFT);

            // If request has trainerId and caller is ADMIN, use it. Otherwise use callerId.
            boolean isAdmin = com.lms.config.UserContextHolder.getUserDto().getRoles().contains("ADMIN");
            String trainerId = (isAdmin && request.getTrainerId() != null) ? request.getTrainerId() : callerId;

            course.setTrainerId(trainerId);
            course.setCreatedBy(callerId);
            course.setUpdatedBy(callerId);
            course.setCreatedAt(LocalDateTime.now());
            course.setUpdatedAt(LocalDateTime.now());
            Course saved = courseRepository.save(course);
            return ApiResponse.success(saved);
        } catch (Exception e) {
            logger.error("Error creating course: {}", e.getMessage());
            return ApiResponse.error(500, "Failed to create course");
        }
    }

    @Override
    public ApiResponse<Course> updateCourse(String courseId, CourseRequest request, String trainerId) {
        Course course = courseRepository.findByIdAndIsDeletedFalse(courseId).orElse(null);
        if (course == null)
            return ApiResponse.error(404, "Course not found");
        if (!course.getTrainerId().equals(trainerId))
            return ApiResponse.error(403, "Not authorized");

        course.setTitle(request.getTitle());
        course.setDescription(request.getDescription());
        course.setPrice(request.getPrice() != null ? request.getPrice() : 0.0);
        course.setThumbnail(request.getThumbnailUrl());
        course.setUpdatedBy(trainerId);
        course.setUpdatedAt(LocalDateTime.now());

        return ApiResponse.success(courseRepository.save(course));
    }

    @Override
    public ApiResponse<String> deleteCourse(String courseId, String trainerId) {
        Course course = courseRepository.findByIdAndIsDeletedFalse(courseId).orElse(null);
        if (course == null)
            return ApiResponse.error(404, "Course not found");
        if (!course.getTrainerId().equals(trainerId))
            return ApiResponse.error(403, "Not authorized");

        course.setDeleted(true);
        course.setUpdatedBy(trainerId);
        course.setUpdatedAt(LocalDateTime.now());
        courseRepository.save(course);
        return ApiResponse.success("Course deleted successfully");
    }

    @Override
    public ApiResponse<Course> getCourseById(String courseId) {
        Course course = courseRepository.findByIdAndIsDeletedFalse(courseId).orElse(null);
        if (course == null)
            return ApiResponse.error(404, "Course not found");
        return ApiResponse.success(course);
    }

    @Override
    public ApiResponse<Object> getAllCourses(int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt"));
        Page<Course> coursePage = courseRepository.findByIsDeletedFalse(pageable);
        return ApiResponse.success(buildPageResponse(coursePage));
    }

    @Override
    public ApiResponse<Object> getPublishedCourses(int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt"));
        Page<Course> coursePage = courseRepository.findByStatusAndIsDeletedFalse(CourseStatus.PUBLISHED, pageable);
        return ApiResponse.success(buildPageResponse(coursePage));
    }

    @Override
    public ApiResponse<Object> getCoursesByTrainer(String trainerId, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt"));
        Page<Course> coursePage = courseRepository.findByTrainerIdAndIsDeletedFalse(trainerId, pageable);
        return ApiResponse.success(buildPageResponse(coursePage));
    }

    @Override
    public ApiResponse<String> publishCourse(String courseId, String trainerId) {
        Course course = courseRepository.findByIdAndIsDeletedFalse(courseId).orElse(null);
        if (course == null)
            return ApiResponse.error(404, "Course not found");
        if (!course.getTrainerId().equals(trainerId))
            return ApiResponse.error(403, "Not authorized");

        course.setStatus(CourseStatus.PUBLISHED);
        course.setUpdatedBy(trainerId);
        course.setUpdatedAt(LocalDateTime.now());
        courseRepository.save(course);
        return ApiResponse.success("Course published successfully");
    }

    public ApiResponse<String> unpublishCourse(String courseId, String trainerId) {
        Course course = courseRepository.findByIdAndIsDeletedFalse(courseId).orElse(null);
        if (course == null)
            return ApiResponse.error(404, "Course not found");
        if (!course.getTrainerId().equals(trainerId))
            return ApiResponse.error(403, "Not authorized");

        course.setStatus(CourseStatus.DRAFT);
        course.setUpdatedBy(trainerId);
        course.setUpdatedAt(LocalDateTime.now());
        courseRepository.save(course);
        return ApiResponse.success("Course unpublished successfully");
    }

    private <T> PageResponse<T> buildPageResponse(Page<T> page) {
        PageResponse<T> response = new PageResponse<>();
        response.setContent(page.getContent());
        response.setPageNumber(page.getNumber());
        response.setPageSize(page.getSize());
        response.setTotalElements(page.getTotalElements());
        response.setTotalPages(page.getTotalPages());
        response.setLast(page.isLast());
        return response;
    }
}
