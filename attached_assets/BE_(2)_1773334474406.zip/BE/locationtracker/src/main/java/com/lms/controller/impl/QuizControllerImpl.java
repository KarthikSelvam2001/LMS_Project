package com.lms.assessment.controller.impl;

import com.lms.assessment.controller.IQuizController;
import com.lms.assessment.dto.QuizAttemptRequest;
import com.lms.assessment.dto.QuizRequest;
import com.lms.assessment.service.IQuizService;
import com.lms.config.UserContextHolder;
import com.lms.entity.Quiz;
import com.lms.entity.QuizAttempt;
import com.lms.response.ApiResponse;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1")
public class QuizControllerImpl implements IQuizController {

    @Autowired
    private IQuizService quizService;

    @Override
    @PostMapping("/lessons/{lessonId}/quizzes")
    @PreAuthorize("hasRole('TRAINER') or hasRole('ADMIN')")
    public ApiResponse<Quiz> createOrUpdateQuiz(@PathVariable String lessonId,
            @Valid @RequestBody QuizRequest request) {
        String trainerId = UserContextHolder.getUserDto().getId();
        return quizService.createOrUpdateQuiz(lessonId, request, trainerId);
    }

    @Override
    @GetMapping("/lessons/{lessonId}/quizzes")
    public ApiResponse<Quiz> getQuizByLesson(@PathVariable String lessonId) {
        return quizService.getQuizByLesson(lessonId);
    }

    @Override
    @DeleteMapping("/quizzes/{quizId}")
    @PreAuthorize("hasRole('TRAINER') or hasRole('ADMIN')")
    public ApiResponse<String> deleteQuiz(@PathVariable String quizId) {
        String trainerId = UserContextHolder.getUserDto().getId();
        return quizService.deleteQuiz(quizId, trainerId);
    }

    @Override
    @PostMapping("/quizzes/{quizId}/attempts")
    @PreAuthorize("hasRole('LEARNER')")
    public ApiResponse<QuizAttempt> submitQuizAttempt(@PathVariable String quizId,
            @Valid @RequestBody QuizAttemptRequest request) {
        String userId = UserContextHolder.getUserDto().getId();
        return quizService.submitQuizAttempt(quizId, request, userId);
    }

    @Override
    @GetMapping("/quizzes/{quizId}/attempts")
    @PreAuthorize("hasRole('LEARNER') or hasRole('TRAINER') or hasRole('ADMIN')")
    public ApiResponse<Object> getUserQuizAttempts(@PathVariable String quizId) {
        String userId = UserContextHolder.getUserDto().getId();
        return quizService.getUserQuizAttempts(quizId, userId);
    }
}
