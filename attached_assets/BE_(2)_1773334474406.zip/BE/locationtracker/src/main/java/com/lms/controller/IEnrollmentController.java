package com.lms.enrollment.controller;

import com.lms.enrollment.dto.EnrollmentRequest;
import com.lms.entity.Enrollment;
import com.lms.response.ApiResponse;
import jakarta.validation.Valid;

public interface IEnrollmentController {
    ApiResponse<Enrollment> enrollUser(@Valid EnrollmentRequest request);

    ApiResponse<Enrollment> getEnrollment(String courseId);

    ApiResponse<Object> getUserEnrollments(int page, int size);

    ApiResponse<Object> getCourseEnrollments(String courseId, int page, int size);
}
