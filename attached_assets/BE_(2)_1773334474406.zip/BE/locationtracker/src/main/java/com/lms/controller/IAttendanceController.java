package com.lms.attendance.controller;

import com.lms.attendance.dto.AttendanceRequest;
import com.lms.entity.Attendance;
import com.lms.response.ApiResponse;
import jakarta.validation.Valid;

public interface IAttendanceController {
    ApiResponse<Attendance> markAttendance(@Valid AttendanceRequest request);

    ApiResponse<Object> getCourseAttendance(String courseId, int page, int size);

    ApiResponse<Double> getCourseProgress(String courseId);
}
