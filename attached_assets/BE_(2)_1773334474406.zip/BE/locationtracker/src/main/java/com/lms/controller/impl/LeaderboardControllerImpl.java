package com.lms.leaderboard.controller.impl;

import com.lms.config.UserContextHolder;
import com.lms.leaderboard.controller.ILeaderboardController;
import com.lms.leaderboard.service.ILeaderboardService;
import com.lms.response.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/leaderboard")
public class LeaderboardControllerImpl implements ILeaderboardController {

    @Autowired
    private ILeaderboardService leaderboardService;

    @Override
    @GetMapping("/top")
    public ApiResponse<Object> getTopLearners(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        return leaderboardService.getTopLearners(page, size);
    }

    @Override
    @GetMapping("/my-rank")
    @PreAuthorize("hasRole('LEARNER')")
    public ApiResponse<Object> getMyRank() {
        String userId = UserContextHolder.getUserDto().getId();
        return leaderboardService.getUserRank(userId);
    }
}
