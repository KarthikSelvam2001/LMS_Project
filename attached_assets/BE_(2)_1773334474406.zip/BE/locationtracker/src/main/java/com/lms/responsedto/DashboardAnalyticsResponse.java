package com.lms.responsedto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DashboardAnalyticsResponse {
    private long totalCourses;
    private long totalLearners;
    private long totalTrainers;
    private long totalEnrollments;

    // Examples of pie chart data mapping
    private List<PieChartData> courseDistributionData; // Courses grouped by categories
    private List<PieChartData> learnerProgressData; // Learner progress categories (Started, Halfway, Completed)

    @Data
    @NoArgsConstructor
    public static class PieChartData {
        private String name;
        private Number value;

        public PieChartData(String name, Number value) {
            this.name = name;
            this.value = value;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public Number getValue() {
            return value;
        }

        public void setValue(Number value) {
            this.value = value;
        }
    }

    public long getTotalCourses() {
        return totalCourses;
    }

    public void setTotalCourses(long totalCourses) {
        this.totalCourses = totalCourses;
    }

    public long getTotalLearners() {
        return totalLearners;
    }

    public void setTotalLearners(long totalLearners) {
        this.totalLearners = totalLearners;
    }

    public long getTotalTrainers() {
        return totalTrainers;
    }

    public void setTotalTrainers(long totalTrainers) {
        this.totalTrainers = totalTrainers;
    }

    public long getTotalEnrollments() {
        return totalEnrollments;
    }

    public void setTotalEnrollments(long totalEnrollments) {
        this.totalEnrollments = totalEnrollments;
    }

    public List<PieChartData> getCourseDistributionData() {
        return courseDistributionData;
    }

    public void setCourseDistributionData(List<PieChartData> courseDistributionData) {
        this.courseDistributionData = courseDistributionData;
    }

    public List<PieChartData> getLearnerProgressData() {
        return learnerProgressData;
    }

    public void setLearnerProgressData(List<PieChartData> learnerProgressData) {
        this.learnerProgressData = learnerProgressData;
    }
}
