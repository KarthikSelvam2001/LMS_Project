package com.lms.service.impl;

import com.lms.responsedto.PageResponse;
import com.lms.entity.Leaderboard;
import com.lms.repository.ILeaderboardRepository;
import com.lms.service.ILeaderboardService;
import com.lms.response.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class LeaderboardServiceImpl implements ILeaderboardService {

    @Autowired
    private ILeaderboardRepository leaderboardRepository;

    @Override
    public ApiResponse<String> addPoints(String userId, int points) {
        Optional<Leaderboard> existingOpt = leaderboardRepository.findByUserIdAndIsDeletedFalse(userId);
        Leaderboard leaderboard = existingOpt.orElse(new Leaderboard());

        leaderboard.setUserId(userId);
        leaderboard.setPoints(leaderboard.getPoints() != null ? leaderboard.getPoints() + points : points);
        leaderboard.setUpdatedBy(userId);
        leaderboard.setUpdatedAt(LocalDateTime.now());

        if (leaderboard.getId() == null) {
            leaderboard.setCreatedBy(userId);
            leaderboard.setCreatedAt(LocalDateTime.now());
        }

        leaderboardRepository.save(leaderboard);
        return ApiResponse.success("Points successfully added");
    }

    @Override
    public ApiResponse<Object> getTopLearners(int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        Page<Leaderboard> leaderboardPage = leaderboardRepository.findByIsDeletedFalseOrderByPointsDesc(pageable);
        return ApiResponse.success(buildPageResponse(leaderboardPage));
    }

    @Override
    public ApiResponse<Object> getUserRank(String userId) {
        Leaderboard userEntry = leaderboardRepository.findByUserIdAndIsDeletedFalse(userId).orElse(null);
        if (userEntry == null) {
            return ApiResponse.error(404, "User not found in leaderboard");
        }
        return ApiResponse.success(userEntry);
    }

    private <T> PageResponse<T> buildPageResponse(Page<T> page) {
        PageResponse<T> response = new PageResponse<>();
        response.setContent(page.getContent());
        response.setPageNumber(page.getNumber());
        response.setPageSize(page.getSize());
        response.setTotalElements(page.getTotalElements());
        response.setTotalPages(page.getTotalPages());
        response.setLast(page.isLast());
        return response;
    }
}
