package com.lms.repository;

import com.lms.entity.Certificate;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ICertificateRepository extends MongoRepository<Certificate, String> {
    Optional<Certificate> findByUserIdAndCourseIdAndIsDeletedFalse(String userId, String courseId);

    Page<Certificate> findByUserIdAndIsDeletedFalse(String userId, Pageable pageable);

    long countByUserId(String userId);

    java.util.List<Certificate> findByUserId(String userId);
}
