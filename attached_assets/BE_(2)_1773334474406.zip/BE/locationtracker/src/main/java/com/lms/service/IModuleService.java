package com.lms.service;

import com.lms.entity.Module;
import com.lms.requestdto.ModuleRequest;
import com.lms.response.ApiResponse;

import java.util.List;

public interface IModuleService {
    ApiResponse<Module> createModule(String courseId, ModuleRequest request, String trainerId);

    ApiResponse<Module> updateModule(String moduleId, ModuleRequest request, String trainerId);

    ApiResponse<String> deleteModule(String moduleId, String trainerId);

    ApiResponse<List<Module>> getCourseModules(String courseId);
}
