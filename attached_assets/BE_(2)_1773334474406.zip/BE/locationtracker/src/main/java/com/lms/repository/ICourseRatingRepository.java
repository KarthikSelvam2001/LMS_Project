package com.lms.repository;

import com.lms.entity.CourseRating;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ICourseRatingRepository extends MongoRepository<CourseRating, String> {
    Optional<CourseRating> findByUserIdAndCourseIdAndIsDeletedFalse(String userId, String courseId);

    Page<CourseRating> findByCourseIdAndIsDeletedFalse(String courseId, Pageable pageable);
}
