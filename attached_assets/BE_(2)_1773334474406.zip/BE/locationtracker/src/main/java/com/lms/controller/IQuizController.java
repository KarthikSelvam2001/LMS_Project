package com.lms.assessment.controller;

import com.lms.assessment.dto.QuizAttemptRequest;
import com.lms.assessment.dto.QuizRequest;
import com.lms.entity.Quiz;
import com.lms.entity.QuizAttempt;
import com.lms.response.ApiResponse;
import jakarta.validation.Valid;

public interface IQuizController {
    ApiResponse<Quiz> createOrUpdateQuiz(String lessonId, @Valid QuizRequest request);

    ApiResponse<Quiz> getQuizByLesson(String lessonId);

    ApiResponse<String> deleteQuiz(String quizId);

    ApiResponse<QuizAttempt> submitQuizAttempt(String quizId, @Valid QuizAttemptRequest request);

    ApiResponse<Object> getUserQuizAttempts(String quizId);
}
