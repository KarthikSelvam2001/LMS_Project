package com.lms.certification.controller.impl;

import com.lms.certification.controller.ICertificateController;
import com.lms.certification.dto.CertificateRequest;
import com.lms.certification.service.ICertificationService;
import com.lms.config.UserContextHolder;
import com.lms.entity.Certificate;
import com.lms.response.ApiResponse;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1")
public class CertificateControllerImpl implements ICertificateController {

    @Autowired
    private ICertificationService certificationService;

    @Override
    @PostMapping("/certificates/generate")
    @PreAuthorize("hasRole('LEARNER')")
    public ApiResponse<Certificate> generateCertificate(@Valid @RequestBody CertificateRequest request) {
        String userId = UserContextHolder.getUserDto().getId();
        return certificationService.generateCertificate(request, userId);
    }

    @Override
    @GetMapping("/courses/{courseId}/certificate")
    @PreAuthorize("hasRole('LEARNER')")
    public ApiResponse<Certificate> getCertificate(@PathVariable String courseId) {
        String userId = UserContextHolder.getUserDto().getId();
        return certificationService.getCertificate(courseId, userId);
    }

    @Override
    @GetMapping("/my-certificates")
    @PreAuthorize("hasRole('LEARNER')")
    public ApiResponse<Object> getUserCertificates(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        String userId = UserContextHolder.getUserDto().getId();
        return certificationService.getUserCertificates(userId, page, size);
    }
}
