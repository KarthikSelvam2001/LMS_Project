package com.lms.repository;

import com.lms.entity.Lesson;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ILessonRepository extends MongoRepository<Lesson, String> {
    List<Lesson> findByModuleIdAndIsDeletedFalseOrderByOrderAsc(String moduleId);
}
