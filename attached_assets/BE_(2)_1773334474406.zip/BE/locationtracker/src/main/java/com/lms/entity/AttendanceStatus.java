package com.lms.entity;

public enum AttendanceStatus {
    PRESENT,
    ABSENT
}
